package com.example.studentmanager.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.studentmanager.entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, UUID> {
    
    Optional<Student> findByStudentCode(String studentCode);

    List<Student> findByFullNameContainingIgnoreCaseOrStudentCodeContainingIgnoreCase(String name, String code);
}