package com.example.studentmanager.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.studentmanager.entity.Student;
import com.example.studentmanager.service.StudentService;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping
    public List<Student> getAllStudents() {
        return studentService.getAll();
    }

    @GetMapping("/{id}")
    public Student getStudentById(@PathVariable UUID id) {
        return studentService.getById(id);
    }

    @GetMapping("/code/{code}")
    public Student getStudentByCode(@PathVariable String code) {
        return studentService.getByStudentCode(code);
    }

    @GetMapping("/search")
    public List<Student> searchStudents(@RequestParam(required = false) String keyword) {
        return studentService.search(keyword);
    }

    @PostMapping
    public Student createStudent(@RequestBody Student student) {
        return studentService.save(student);
    }

    @PutMapping("/{id}")
    public Student updateStudent(@PathVariable UUID id, @RequestBody Student student) {
        student.setId(id);
        return studentService.save(student);
    }

    @DeleteMapping("/{id}")
    public String deleteStudent(@PathVariable UUID id) {
        studentService.delete(id);
        return "Đã xóa thành công sinh viên có id: " + id;
    }

    @DeleteMapping
    public String deleteAllStudents() {
        studentService.deleteAll();
        return "Đã xóa tất cả sinh viên!";
    }
}