# Upgrade Plan: studentmanager (20260823033708)

- **Generated**: 2026-08-23 03:37:08
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 21: not available (baseline will be skipped)
- JDK 25: **<TO_BE_INSTALLED>** (required by Step 1)

**Build Tools**
- Maven Wrapper: 3.9.16 (distributionUrl in .mvn/wrapper/maven-wrapper.properties)
- System Maven: not available (will use Maven Wrapper)

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260823033708
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java: upgrade from 21 → 25 (latest LTS requested by user)

## Technology Stack

| Technology/Dependency    | Current | Min Compatible | Why Incompatible                               |
| ------------------------ | ------- | -------------- | ---------------------------------------------- |
| Java                     | 21      | 25             | User requested upgrade to latest LTS           |
| Spring Boot              | 4.1.1   | 4.1.1          | Compatible with Java 25; no change required    |
| Maven Wrapper            | 3.9.16  | 3.9.16         | Wrapper present and adequate                   |

## Derived Upgrades

- None required apart from installing JDK 25 and updating project Java target property.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| pom.xml | `java.version` property | 21 | upgrade | 25 | Set javac target to Java 25 runtime |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| pom.xml | `<properties>` | `<java.version>21</java.version>` | Update to `<java.version>25</java.version>` | Ensure compile target matches requested runtime |

### Configuration Changes

- None other than `pom.xml` property update.

### CI/CD Changes

- None detected in repository. Update CI/CD manually if pipelines reference Java 21.

### Risks & Warnings

- Base JDK 21 not available on host: baseline compile/tests will be skipped. Manual verification recommended if baseline evidence is required.
- Runtime-only issues (reflection, internal JDK APIs) are unlikely for a small Spring Boot app but should be monitored during Final Validation.

## Upgrade Steps

- Step 1: Install JDK 25
  - **Rationale**: Required to compile and run with Java 25
  - **Changes to Make**: Install JDK 25 on host (system or managed install) and make it available to the build commands
  - **Verification**: `java -version` shows 25; `mvn -v` (using mvnw) runs with JDK 25

- Step 2: (Baseline) Skip baseline compile/tests
  - **Rationale**: Project's current JDK (21) is not available on host
  - **Changes to Make**: None
  - **Verification**: Marked skipped

- Step 3: Update `pom.xml` java.version → 25
  - **Rationale**: Ensure the project compiles with target JVM 25
  - **Changes to Make**: Edit `pom.xml` `<properties>` change `21`→`25`
  - **Verification**: `./mvnw -q -DskipTests=false clean test-compile` with JDK 25 should compile

- Step 4: Build and run tests on JDK 25
  - **Rationale**: Validate compilation and test suite under target JDK
  - **Changes to Make**: None beyond Step 3
  - **Verification**: `./mvnw -q clean test` — Expected: all tests pass

- Step 5: CVE scan & fix
  - **Rationale**: Ensure direct dependencies have no known CVEs
  - **Changes to Make**: Run CVE validation tool and upgrade direct dependencies if issues found
  - **Verification**: CVE scanner returns no open issues for direct dependencies

- Step 6: Final validation & summary
  - **Rationale**: Ensure upgrade goals met and produce `summary.md`
  - **Changes to Make**: Fix any remaining test failures; run coverage if requested
  - **Verification**: `./mvnw -q clean test` — 100% pass


(End of plan)
